package br.gov.sp.cps.perfil.humor;

import android.os.Bundle;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import br.gov.sp.cps.perfil.R;

public class HumorResultadoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_humor_resultado);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_resultado_humor), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        double score = getIntent().getDoubleExtra("SCORE_FELICIDADE", 0);
        TextView txtScore = findViewById(R.id.txtScoreHumor);
        TextView txtStatus = findViewById(R.id.txtStatusHumor);

        txtScore.setText(String.format("%.1f", score));

        // Tabela de Classificação
        if (score <= 2.0) {
            txtStatus.setText("Muito Baixa\n(Alerta crítico)");
            txtStatus.setTextColor(android.graphics.Color.RED);
        } else if (score <= 4.0) {
            txtStatus.setText("Baixa\n(Equilíbrio precário)");
            txtStatus.setTextColor(android.graphics.Color.parseColor("#FF9800")); // Laranja
        } else if (score <= 6.0) {
            txtStatus.setText("Moderada\n(Estado neutro)");
            txtStatus.setTextColor(android.graphics.Color.GRAY);
        } else if (score <= 8.0) {
            txtStatus.setText("Alta\n(Bom equilíbrio)");
            txtStatus.setTextColor(android.graphics.Color.parseColor("#4CAF50")); // Verde
        } else {
            txtStatus.setText("Plena\n(Estado ideal)");
            txtStatus.setTextColor(android.graphics.Color.parseColor("#2E7D32")); // Verde Escuro
        }

        findViewById(R.id.btnVoltarHumorCalculo).setOnClickListener(v -> finish());
    }
}