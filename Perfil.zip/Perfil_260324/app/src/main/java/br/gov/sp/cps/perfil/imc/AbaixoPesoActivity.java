package br.gov.sp.cps.perfil.imc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

// Mantenha o R para os IDs funcionarem
import br.gov.sp.cps.perfil.R;

public class AbaixoPesoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Certifique-se que o nome do XML está correto
        setContentView(R.layout.activity_abaixo_peso);

        String nome = getIntent().getStringExtra("NOME");
        String peso = getIntent().getStringExtra("PESO");
        String altura = getIntent().getStringExtra("ALTURA");
        double imc = getIntent().getDoubleExtra("RESULTADO_IMC", 0);

        ((TextView)findViewById(R.id.txtValorAbaixo)).setText(String.format("%.2f", imc));
        ((TextView)findViewById(R.id.txtResumoAbaixo)).setText(nome + "\nPeso: " + peso + "kg | Altura: " + altura + "m");

        // Configurando o botão Voltar
        findViewById(R.id.btnVoltarAbaixo).setOnClickListener(v -> {
            // MUDANÇA AQUI: Agora volta para a tela de digitar peso/altura
            Intent intent = new Intent(this, ImcActivity.class);
            startActivity(intent);

            // Fecha a tela de resultado
            finish();
        });
    }
}