package br.gov.sp.cps.perfil.imc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import br.gov.sp.cps.perfil.R;

public class Obesidade3Activity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_obesidade3);

        String nome = getIntent().getStringExtra("NOME");
        String peso = getIntent().getStringExtra("PESO");
        String altura = getIntent().getStringExtra("ALTURA");
        double imc = getIntent().getDoubleExtra("RESULTADO_IMC", 0);

        ((TextView)findViewById(R.id.txtValorOb3)).setText(String.format("%.2f", imc));
        ((TextView)findViewById(R.id.txtResumoOb3)).setText(nome + "\nPeso: " + peso + "kg | Altura: " + altura + "m");

        findViewById(R.id.btnVoltarOb3).setOnClickListener(v -> {
            startActivity(new Intent(this, ImcActivity.class));
            finish();
        });
    }
}