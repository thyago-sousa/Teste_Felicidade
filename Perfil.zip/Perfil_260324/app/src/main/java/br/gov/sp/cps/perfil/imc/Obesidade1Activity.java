package br.gov.sp.cps.perfil.imc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import br.gov.sp.cps.perfil.R;

public class Obesidade1Activity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_obesidade1);

        String nome = getIntent().getStringExtra("NOME");
        String peso = getIntent().getStringExtra("PESO");
        String altura = getIntent().getStringExtra("ALTURA");
        double imc = getIntent().getDoubleExtra("RESULTADO_IMC", 0);

        ((TextView)findViewById(R.id.txtValorOb1)).setText(String.format("%.2f", imc));
        ((TextView)findViewById(R.id.txtResumoOb1)).setText(nome + "\nPeso: " + peso + "kg | Altura: " + altura + "m");

        findViewById(R.id.btnVoltarOb1).setOnClickListener(v -> {
            // Volta para a tela de cálculo (ImcActivity)
            startActivity(new Intent(this, ImcActivity.class));
            finish();
        });
    }
}