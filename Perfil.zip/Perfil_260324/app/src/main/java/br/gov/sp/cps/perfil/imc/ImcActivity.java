package br.gov.sp.cps.perfil.imc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

// IMPORTANTE: Importando a MainActivity que está na pasta pai (perfil)
import br.gov.sp.cps.perfil.MainActivity;
import br.gov.sp.cps.perfil.R;

public class ImcActivity extends AppCompatActivity {

    private EditText editNome, editPeso, editAltura;
    private Button btnCalcular, btnLimpar, btnVoltarMenu; // Adicionado btnVoltarMenu

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_imc_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_imc), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicialização dos componentes
        editNome = findViewById(R.id.editNome);
        editPeso = findViewById(R.id.editPeso);
        editAltura = findViewById(R.id.editAltura);
        btnCalcular = findViewById(R.id.btnCalcular);
        btnLimpar = findViewById(R.id.btnLimpar);
        btnVoltarMenu = findViewById(R.id.btnVoltarMenu); // Novo botão

        // Lógica do botão Limpar
        btnLimpar.setOnClickListener(v -> {
            editNome.setText("");
            editPeso.setText("");
            editAltura.setText("");
            editNome.requestFocus();
            Toast.makeText(this, "Campos limpos!", Toast.LENGTH_SHORT).show();
        });

        // Lógica do botão Voltar ao Menu (Perfil)
        btnVoltarMenu.setOnClickListener(v -> {
            // Volta para a tela principal de 4 botões
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish(); // Fecha a calculadora ao sair para o menu
        });

        // Lógica do botão Calcular
        btnCalcular.setOnClickListener(v -> {
            String nome = editNome.getText().toString();
            String sPeso = editPeso.getText().toString();
            String sAltura = editAltura.getText().toString();

            if (nome.isEmpty() || sPeso.isEmpty() || sAltura.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double peso = Double.parseDouble(sPeso);
                double altura = Double.parseDouble(sAltura);
                double imc = peso / (altura * altura);

                Intent intent;
                if (imc < 18.5) intent = new Intent(this, AbaixoPesoActivity.class);
                else if (imc < 25) intent = new Intent(this, PesoNormalActivity.class);
                else if (imc < 30) intent = new Intent(this, SobrepesoActivity.class);
                else if (imc < 35) intent = new Intent(this, Obesidade1Activity.class);
                else if (imc < 40) intent = new Intent(this, Obesidade2Activity.class);
                else intent = new Intent(this, Obesidade3Activity.class);

                intent.putExtra("NOME", nome);
                intent.putExtra("PESO", sPeso);
                intent.putExtra("ALTURA", sAltura);
                intent.putExtra("RESULTADO_IMC", imc);

                startActivity(intent);

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Use números válidos!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}