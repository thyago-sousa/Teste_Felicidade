package br.gov.sp.cps.perfil.jokenpo; // Ajustado para sua nova estrutura

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

import br.gov.sp.cps.perfil.MainActivity; // Import do menu principal
import br.gov.sp.cps.perfil.R;

public class JokenpoActivity extends AppCompatActivity {

    private int pontosPlayer = 0;
    private int pontosApp = 0;
    private boolean jogoAtivo = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Ajuste para o nome do XML (sugiro renomear para activity_jokenpo)
        setContentView(R.layout.activity_jokenpo);

        // Configuração do botão de voltar que adicionaremos no XML
        Button btnSair = findViewById(R.id.btnVoltarJokenpo);
        btnSair.setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }

    public void selecionadoPedra(View view) { this.opcaoSelecionada("pedra"); }
    public void selecionadoPapel(View view) { this.opcaoSelecionada("papel"); }
    public void selecionadoTesoura(View view) { this.opcaoSelecionada("tesoura"); }

    public void opcaoSelecionada(String escolhaUsuario) {
        if (!jogoAtivo) return;

        ImageView imagemRobo = findViewById(R.id.imageRobo);
        TextView textResultado = findViewById(R.id.textResultado);
        TextView textPlacar = findViewById(R.id.textPlacar);

        int x = new Random().nextInt(3);
        String[] opcoes = {"pedra", "papel", "tesoura"};
        String escolhaApp = opcoes[x];

        switch (escolhaApp) {
            case "pedra": imagemRobo.setImageResource(R.drawable.pedra); break;
            case "papel": imagemRobo.setImageResource(R.drawable.papel); break;
            case "tesoura": imagemRobo.setImageResource(R.drawable.tesoura); break;
        }

        // Lógica de vitória/derrota (mantida)
        if ((escolhaApp.equals("tesoura") && escolhaUsuario.equals("papel")) ||
                (escolhaApp.equals("papel") && escolhaUsuario.equals("pedra")) ||
                (escolhaApp.equals("pedra") && escolhaUsuario.equals("tesoura"))) {
            pontosApp++;
            textResultado.setText("Você perdeu essa rodada!");
        } else if ((escolhaUsuario.equals("tesoura") && escolhaApp.equals("papel")) ||
                (escolhaUsuario.equals("papel") && escolhaApp.equals("pedra")) ||
                (escolhaUsuario.equals("pedra") && escolhaApp.equals("tesoura"))) {
            pontosPlayer++;
            textResultado.setText("Você ganhou essa rodada!");
        } else {
            textResultado.setText("Empatamos! ;)");
        }

        atualizarPlacar(textPlacar, textResultado);
    }

    private void atualizarPlacar(TextView placar, TextView resultado) {
        placar.setText("PC " + pontosApp + " x " + pontosPlayer + " YOU");
        if (pontosApp == 2) {
            resultado.setText("O COMPUTADOR VENCEU!");
            jogoAtivo = false;
        } else if (pontosPlayer == 2) {
            resultado.setText("VOCÊ VENCEU!");
            jogoAtivo = false;
        }
    }

    public void reiniciarJogo(View view) {
        pontosApp = 0;
        pontosPlayer = 0;
        jogoAtivo = true;
        TextView textPlacar = findViewById(R.id.textPlacar);
        TextView textResultado = findViewById(R.id.textResultado);
        ImageView imagemRobo = findViewById(R.id.imageRobo);
        textPlacar.setText("PC 0 x 0 YOU");
        textResultado.setText("Escolha uma opção abaixo");
        imagemRobo.setImageResource(R.drawable.padrao);
    }
}