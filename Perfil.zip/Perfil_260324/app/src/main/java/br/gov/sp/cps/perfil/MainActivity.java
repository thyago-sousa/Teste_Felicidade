package br.gov.sp.cps.perfil;

import android.content.Intent;
import android.os.Bundle;
// Removi o Toast porque agora vamos abrir a tela de verdade!

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

// IMPORTANTE: Adicione este import para o botão de humor funcionar
import br.gov.sp.cps.perfil.humor.HumorActivity;

import br.gov.sp.cps.perfil.imc.ImcActivity;
import br.gov.sp.cps.perfil.jokenpo.JokenpoActivity;
import br.gov.sp.cps.perfil.megasena.MegaSenaActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        findViewById(R.id.btnMegaSena).setOnClickListener(v -> {
            startActivity(new Intent(this, MegaSenaActivity.class));
        });

        findViewById(R.id.btnImc).setOnClickListener(v -> {
            startActivity(new Intent(this, ImcActivity.class));
        });

        findViewById(R.id.btnJokenpo).setOnClickListener(v -> {
            startActivity(new Intent(this, JokenpoActivity.class));
        });

        findViewById(R.id.btnHumor).setOnClickListener(v -> {
            startActivity(new Intent(this, HumorActivity.class));
        });
    }
}