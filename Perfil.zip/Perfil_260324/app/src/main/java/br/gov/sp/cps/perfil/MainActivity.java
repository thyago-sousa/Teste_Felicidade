package br.gov.sp.cps.perfil;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import br.gov.sp.cps.perfil.imc.ImcActivity;
import br.gov.sp.cps.perfil.jokenpo.JokenpoActivity;
import br.gov.sp.cps.perfil.megasena.MegaSenaActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // 1. Configurar Botão Mega-Sena
        findViewById(R.id.btnMegaSena).setOnClickListener(v -> {
            startActivity(new Intent(this, MegaSenaActivity.class));
        });

        // 2. Configurar Botão IMC
        findViewById(R.id.btnImc).setOnClickListener(v -> {
            startActivity(new Intent(this, ImcActivity.class));
        });

        // 3. Configurar Botão Jokenpo
        findViewById(R.id.btnJokenpo).setOnClickListener(v -> {
            startActivity(new Intent(this, JokenpoActivity.class));
        });

        // 4. Configurar Botão Teste de Humor (Aviso enquanto não está pronto)
        findViewById(R.id.btnHumor).setOnClickListener(v -> {
            Toast.makeText(this, "Em desenvolvimento...", Toast.LENGTH_SHORT).show();
            // Quando criar a activity, use: startActivity(new Intent(this, HumorActivity.class));
        });
    }
}