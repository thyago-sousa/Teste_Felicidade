package br.gov.sp.cps.perfil.humor;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import br.gov.sp.cps.perfil.MainActivity;
import br.gov.sp.cps.perfil.R;

public class HumorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_humor);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_humor), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        CheckBox cbEstudo = findViewById(R.id.cbEstudando);
        CheckBox cbTrabalho = findViewById(R.id.cbTrabalhando);
        CheckBox cbFolga = findViewById(R.id.cbFolga);

        RadioGroup rgSono = findViewById(R.id.rgSono);
        RadioGroup rgEstresse = findViewById(R.id.rgEstresse);

        Button btnCalcular = findViewById(R.id.btnCalcularHumor);
        Button btnVoltar = findViewById(R.id.btnVoltarHumorMenu);

        btnVoltar.setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });

        btnCalcular.setOnClickListener(v -> {
            boolean algumaAtividade = cbEstudo.isChecked() || cbTrabalho.isChecked() || cbFolga.isChecked();

            int idSono = rgSono.getCheckedRadioButtonId();
            int idEstresse = rgEstresse.getCheckedRadioButtonId();

            if (!algumaAtividade || idSono == -1 || idEstresse == -1) {
                Toast.makeText(this, "Responda sobre sua atividade, sono e estresse!", Toast.LENGTH_SHORT).show();
                return;
            }

            int s = 0, e = 0;

            if (idSono == R.id.rbSono1) s = 1;
            else if (idSono == R.id.rbSono2) s = 3;
            else if (idSono == R.id.rbSono3) s = 2;

            if (idEstresse == R.id.rbEstresse1) e = 3;
            else if (idEstresse == R.id.rbEstresse2) e = 2;
            else if (idEstresse == R.id.rbEstresse3) e = 1;

            double felicidade = ((double)(s + e) / 6) * 10;

            Intent intent = new Intent(this, HumorResultadoActivity.class);
            intent.putExtra("SCORE_FELICIDADE", felicidade);
            startActivity(intent);
        });
    }
}